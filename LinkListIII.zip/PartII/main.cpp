
#include "List.hpp"
#include "Node.hpp"

int main()

{
	List Student_List;

	ifstream fip;		

	int  id;
	char read_first[20];
	char read_last[20];
	int  cred;
	int  dobm;
	int  dobd;
	int  doby;

	char * dyn_first;
	char * dyn_last;
	
	StudentRecord * new_student;

	fip.open("Students.txt");
	
	if(!fip) {cout << "NO FILE!" << endl; return 0;}

	while(!fip.eof() && fip >> id) {

			
		//fip >> id;
		// cout << "ID: " << id;
		fip.ignore();
		fip.get(read_first, 20, ' '); cout << "F: " << read_first;
		fip.ignore();
		fip.get(read_last, 20, ' '); cout << "  L: " << read_last;
		fip.ignore();
		fip >> cred;	cout << " cred: " << cred;
		fip.ignore();
		fip >> dobm;	
		fip.ignore();
		fip >> dobd;
		fip.ignore();
		fip >> doby;	cout << " DOB: " << dobm << "/" << dobd << "/" << doby << endl;
		fip.ignore();
	
		int len = strlen(read_first) + 1;
		dyn_first = new char[len];
		strcpy(dyn_first, read_first);			
			
		len = strlen(read_last) + 1;
		dyn_last = new char[len];
		strcpy(dyn_last, read_last);
		
		new_student = new StudentRecord(id, dyn_first, dyn_last, cred, dobm, doby, dobd);				
		Student_List.addNode(new_student);
		}		
		Student_List.display();
}

