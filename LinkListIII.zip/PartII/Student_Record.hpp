#ifndef student_class
#define student_class

//Student_Record.hpp


class StudentRecord {

	private:
	int ID;
	char * first_name;
	char * last_name;
	int credits;
	int dob_month;
	int dob_year;
	int dob_day;
	

	public: 
	StudentRecord(int id, char * f, char * l, int credits_in, int dob_m, int dob_y, int dob_d);
	
	void setFirst(char * );  
	void setLast(char * );
	void setCredits(int);
	void setDobMonth(int);
	void setDobYear(int);
	void setDobDay(int);
	char * getFirst();
	char * getLast();
	int  getCredits();
	int  getDobMonth();
	int  getDobYear();
	int  getDobDay();
 	void  setId(int id_in);		
	int  getId();
	void StuRecdisplay();
};

#endif
