
#ifndef _Node_hpp_
#define _Node_hpp_

#include "Student_Record.hpp"


class Node {
    private:
        int Id;
        Node * next;
	StudentRecord * student_data;
    public:
        Node(StudentRecord * new_student);
	~Node();
        Node();
	
        void setId(int);
        int getId();

        void setNext(Node *);
        Node * getNext();

	void setStudent_data(StudentRecord * ptr);
	StudentRecord * getStudentdata();	

        void display();
	
};
#endif


