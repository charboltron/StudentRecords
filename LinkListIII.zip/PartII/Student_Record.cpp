#include "List.hpp"
#include "Student_Record.hpp"    


StudentRecord::StudentRecord(int id_in, char * f, char * l, int hours_in, int credits_in, int dob_m, int dob_y, int dob_d)
{
	/*ID = id_in;  
	first_name = f;
	last_name = l;
	credits = credits_in;
	dob_month = dob_m;
	dob_year = dob_y;
	dob_day = dob_d;

	cout << "ID from constructor: " << ID << endl;
	cout << "fn from constructor: " << first_name << endl;
	cout << "ln from constructor: " << last_name << endl;
	cout << "cr from constructor: " << credits << endl;
	cout << "dm from constructor: " << dob_month << endl;
	cout << "dy from constructor: " << dob_year << endl;
	cout << "dd from constructor: " << dob_day << endl;*/
	
	setId(id_in);
	setFirst(f);
	setLast(l);
	setCredits(credits_in);
	setHours(hours_in);
	setDobMonth(dob_m);
	setDobYear(dob_y);
	setDobDay(dob_d); 

	
}

StudentRecord:: ~StudentRecord() {

	if(first_name) {delete first_name;}      
	if(last_name) {delete last_name;}   
}   
void StudentRecord::setFirst(char *f ){
	
	first_name = f;

}

void StudentRecord::setLast(char * l){
	last_name = l;
}

void StudentRecord::setCredits(int x){

	credits = x;
}

void StudentRecord::setHours(int x){

	hours = x;

}
        
void StudentRecord::setDobMonth(int x){

	dob_month = x;

}

void StudentRecord::setDobYear(int x){

	dob_year = x;
}
        
void StudentRecord::setDobDay(int x){

	dob_day = x;
}

char * StudentRecord::getFirst(){
	
	return first_name;
}

char * StudentRecord::getLast(){

	return last_name;
}
int  StudentRecord::getCredits(){

	return credits;
}

int  StudentRecord::getHours() {

	return hours;
}
int  StudentRecord::getDobMonth(){

	return dob_month;
}

int  StudentRecord::getDobYear(){
	
	return dob_year;
}
 
int  StudentRecord::getDobDay(){

	return dob_day;
}

void StudentRecord::setId(int id_in) {

	ID = id_in;
}
int StudentRecord::getId() {
	
	return ID;
}

void StudentRecord::StuRecdisplay() {

	cout << "Student ID: " << ID << endl;
	cout << "First Name: " << first_name << endl;
	cout <<"Last Name:  " << last_name << endl; 
	cout << "DOB: " << dob_month << "/" << dob_day << "/" << dob_year << endl; 
	cout << setw(5) << "Credits: " << credits << setw(5) << " Hours: " << hours << endl;
	cout << "GPA: " << setw(5) << showpoint << fixed << setprecision(2) << static_cast<double>(credits)/hours << endl; 
	cout << endl << endl;

} 
