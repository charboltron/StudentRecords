/* Copyright (c) 2018 Jason Graalum
 *
 * Node.cpp
 *
 * Class implementation for Node class
 *
 * Practice: Part II code
 *
 * All data members and member functions are public
 *
 */
#include "Node.hpp"
#include "List.hpp"
//
// Default constructor
//
Node::Node(int id_in) {
    Id = id_in;
    next = NULL;
}

//
// Constructor which populates Node data during construction
//
//Node::Node(int d) {
//    id = d;
//    next = NULL;
//}

//
// Simple setter function for the Node data
//
void Node::setId(int d) {
    Id = d;
}

//
// Simple getter function for the Node data
//
int Node::getId() {
    return Id;
}

//
// Simple setter function for the Node next pointer
//
void Node::setNext(Node * n) {
    next = n;
}

//
// Simple getter function for the Node next pointer
//
Node * Node::getNext() {
    return next;
}

void Node::setStudent_data(StudentRecord * ptr){

    student_data = ptr;

}

StudentRecord * Node::getStudentdata(){
	
    return student_data;
}



//
// Simple display method
//
void Node::display() {

	cout << "node disp func before student_data->display" << endl;
    	student_data->StuRecdisplay();
}


