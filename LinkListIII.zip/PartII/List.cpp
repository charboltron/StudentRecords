/* Copyright (c) 2018 Jason Graalum
 *
 * List.cpp
 *
 * Class implementation for Linked List class
 *
 * Practice: Part II code
 *
 * All data members and member functions are public
 *
 */

#include "List.hpp"

// 
// Constructor sets the head pointer to NULL
// indicating an empty list
//
List::List() {
    head = NULL;
}

List::~List() { 

    if(head) {delete head;}

}
//
// Method to add a new node to the list
//
void List::addNode(StudentRecord * new_student) {
    // Use the new constructor passing in the data
    // the new Node
    Node * temp = new Node(new_student);
    temp->setId(new_student->getId());

    //cout << "new_st ID: " << new_student->getId()<< endl;
    // Case 1: head is NULL means List is empty
    if(head == NULL) { cout << "ONE!" << endl;
        head = temp;
        temp->setNext(NULL);
    }

		
    // Case 2: Insert at the beginning of the List
    else if(new_student->getId() < head->getId()) { //cout << "TWO" << endl;
        temp->setNext(head);
        head = temp;
    }
    // Case 3/4: Insert in the middle or at the end of the List
    else { // cout << "head ID:   " <<  head->getId() <<  " -->THREE" << endl;  
        // current pointer to track traversal through LinkedList
        Node * current = head;
        while(current->getNext() != NULL && current->getNext()->getId() < new_student->getId())
        {
            current = current->getNext();
        }
        temp->setNext(current->getNext());
        current->setNext(temp);
    }
}

//
// Simple list display method
//
void List::display() {
		
  Node * temp;
  temp = head;
	
	
	
  while(temp != NULL) {
    
      temp->display();
      temp = temp->getNext();
  }
}


