/* Copyright (c) 2018 Jason Graalum
 *
 * List.hpp
 *
 * Class interface for Linked List class
 *
 * Practice: Part II code
 *
 * All data members and member functions are public
 *
 */
#ifndef _List_hpp_
#define _List_hpp_

#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include "Node.hpp"
#include "Student_Record.hpp"

using namespace std;

class List {
    private:
        Node * head;
    public:
        List();
        void addNode(StudentRecord * ptr);
        void display();
};

#endif
